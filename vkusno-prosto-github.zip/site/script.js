// Вкусно Просто: минимальный скрипт. Контент страниц отдаётся готовым HTML, JS нужен только для интерфейса.
(function () {
  var goal = function (name) {
    var counter = document.documentElement.dataset.metrikaId;
    if (counter && typeof window.ym === "function") window.ym(Number(counter), "reachGoal", name);
  };
  document.querySelectorAll('a[href^="mailto:"]').forEach(function (link) {
    link.addEventListener("click", function () { goal("contact_click"); });
  });
  var toggle = document.getElementById("menuToggle"), nav = document.getElementById("mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
      toggle.textContent = open ? "×" : "☰";
    });
  }
  function readList(key) {
    try {
      const values = JSON.parse(localStorage.getItem(key));
      return new Set(Array.isArray(values) ? values : []);
    } catch {
      return new Set();
    }
  }

  function writeList(key, values) {
    try { localStorage.setItem(key, JSON.stringify([...values])); } catch { /* Работа в текущей вкладке сохраняется. */ }
  }

  function makeButton(label, cssClass) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = cssClass;
    button.textContent = label;
    return button;
  }

  const favoritesKey = "vkusno-prosto:favorites";
  const favorites = readList(favoritesKey);
  const favoriteButtons = [];
  let refreshCatalog = function () {};

  function addFavoriteButton(container, address, title, photo) {
    const url = new URL(address, location.href);
    const key = url.pathname + url.hash;
    const button = makeButton("", photo ? "favorite-heart" : "interaction-button favorite-button");
    button.setAttribute("aria-label", "Избранное: " + title);
    const icon = document.createElement("span");
    icon.className = "heart-icon";
    icon.setAttribute("aria-hidden", "true");
    button.append(icon);
    const caption = document.createTextNode("");
    if (!photo) button.append(caption);
    function update() {
      const saved = favorites.has(key);
      button.setAttribute("aria-pressed", String(saved));
      button.title = saved ? "Убрать из избранного" : "Сохранить в избранное";
      icon.textContent = saved ? "♥" : "♡";
      caption.data = saved ? " В избранном" : " В избранное";
    }
    favoriteButtons.push(update);
    button.addEventListener("click", function () {
      if (favorites.has(key)) favorites.delete(key);
      else favorites.add(key);
      writeList(favoritesKey, favorites);
      favoriteButtons.forEach(updateButton => updateButton());
      refreshCatalog();
    });
    update();
    if (photo) photo.after(button);
    else container.append(button);
    return key;
  }

  const search = document.getElementById("hubSearch");
  const grid = document.getElementById("hubGrid");
  const count = document.getElementById("hubCount");
  if (search && grid && count) {
    const cards = [...grid.children].map(card => {
      const link = card.querySelector(".card-title a");
      const searchText = card.textContent.toLowerCase();
      const key = addFavoriteButton(card, link.href, link.textContent.trim(), card.querySelector(".recipe-photo"));
      return { card, link, searchText, key };
    });
    const plural = new Intl.PluralRules("ru");
    const toolbar = document.createElement("div");
    toolbar.className = "catalog-tools";
    const savedFilter = makeButton("Избранное", "interaction-button");
    savedFilter.setAttribute("aria-pressed", "false");
    const random = makeButton("Случайный рецепт", "interaction-button surprise-button");
    toolbar.append(savedFilter, random);
    count.before(toolbar);
    let onlySaved = false;
    let visibleCards = cards;
    refreshCatalog = function () {
      const query = search.value.trim().toLowerCase();
      visibleCards = cards.filter(({ card, key, searchText }) => {
        const show = searchText.includes(query) && (!onlySaved || favorites.has(key));
        if (!show && card.contains(document.activeElement)) savedFilter.focus({ preventScroll: true });
        card.hidden = !show;
        return show;
      });
      const shown = visibleCards.length;
      const label = { one: "рецепт", few: "рецепта", many: "рецептов" }[plural.select(shown)];
      count.textContent = shown ? `${shown} ${label}` :
        (onlySaved && !query ? "Здесь появятся сохранённые рецепты." : "Ничего не найдено. Измените запрос.");
      savedFilter.textContent = `Избранное (${cards.filter(({ key }) => favorites.has(key)).length})`;
      random.disabled = shown === 0;
    };
    savedFilter.addEventListener("click", function () {
      onlySaved = !onlySaved;
      savedFilter.setAttribute("aria-pressed", String(onlySaved));
      refreshCatalog();
    });
    random.addEventListener("click", function () {
      const choice = visibleCards[Math.floor(Math.random() * visibleCards.length)];
      if (choice) location.assign(choice.link.href);
    });
    let searchTimer;
    search.addEventListener("input", function () {
      clearTimeout(searchTimer);
      if (search.value.trim()) searchTimer = setTimeout(() => goal("recipe_search"), 700);
      refreshCatalog();
    });
    refreshCatalog();
  }

  const ingredients = document.querySelector(".ingredients");
  if (ingredients) {
    const title = document.querySelector("main h1");
    if (title) addFavoriteButton(title.parentElement, location.pathname, title.textContent.trim());
    const key = "vkusno-prosto:ingredients:" + location.pathname;
    const checked = readList(key);
    const controls = document.createElement("div");
    controls.className = "catalog-tools ingredient-tools";
    const progress = document.createElement("span");
    progress.setAttribute("aria-live", "polite");
    const reset = makeButton("Сбросить отметки", "interaction-button");
    controls.append(progress, reset);
    ingredients.before(controls);
    ingredients.classList.add("interactive-ingredients");
    const boxes = [...ingredients.children].map(item => {
      const label = document.createElement("label");
      const box = document.createElement("input");
      const name = item.textContent.trim();
      box.type = "checkbox";
      box.checked = checked.has(name);
      label.append(box, ...item.childNodes);
      item.append(label);
      box.addEventListener("change", function () {
        if (box.checked) checked.add(name);
        else checked.delete(name);
        updateProgress();
      });
      return box;
    });
    function updateProgress() {
      const done = boxes.filter(box => box.checked).length;
      progress.textContent = `Подготовлено ${done} из ${boxes.length}`;
      reset.hidden = done === 0;
      writeList(key, checked);
    }
    reset.addEventListener("click", function () {
      boxes.forEach(box => { box.checked = false; });
      checked.clear();
      updateProgress();
      boxes[0].focus();
    });
    updateProgress();
  }

  const dailyRecipes = document.querySelectorAll("#dailyRecipe > .daily-recipe");
  if (dailyRecipes.length) {
    const now = new Date();
    const day = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86400000);
    const selected = day % dailyRecipes.length;
    dailyRecipes.forEach((recipe, index) => { recipe.hidden = index !== selected; });
  }

  function openCookingMode(recipe, steps, trigger) {
    const dialog = document.createElement("dialog");
    dialog.className = "cooking-dialog";
    dialog.setAttribute("aria-labelledby", "cooking-title");
    dialog.innerHTML = `
      <div class="cooking-header">
        <h2 id="cooking-title" tabindex="-1" autofocus></h2>
        <button class="interaction-button cooking-close" type="button" data-close aria-label="Закрыть режим готовки">×</button>
      </div>
      <div class="cooking-body">
        <p class="cooking-step-number" aria-live="polite"></p>
        <progress aria-label="Текущий шаг рецепта"></progress>
        <p class="cooking-instruction" tabindex="-1"></p>
        <section class="cooking-timer" aria-label="Кухонный таймер" hidden>
          <div>
            <p class="cooking-timer-label"></p>
            <output class="cooking-clock" role="timer"></output>
          </div>
          <div class="cooking-timer-actions">
            <button class="interaction-button" type="button" data-timer-toggle></button>
            <button class="interaction-button" type="button" data-timer-reset>Сбросить</button>
          </div>
        </section>
        <p class="cooking-status" role="status"></p>
      </div>
      <div class="cooking-footer">
        <button class="interaction-button" type="button" data-back>Назад</button>
        <button class="interaction-button surprise-button" type="button" data-next>Далее</button>
      </div>`;
    const title = dialog.querySelector("h2");
    const stepNumber = dialog.querySelector(".cooking-step-number");
    const progress = dialog.querySelector("progress");
    const instruction = dialog.querySelector(".cooking-instruction");
    const timer = dialog.querySelector(".cooking-timer");
    const timerLabel = dialog.querySelector(".cooking-timer-label");
    const clock = dialog.querySelector(".cooking-clock");
    const status = dialog.querySelector(".cooking-status");
    const timerToggle = dialog.querySelector("[data-timer-toggle]");
    const timerReset = dialog.querySelector("[data-timer-reset]");
    const back = dialog.querySelector("[data-back]");
    const next = dialog.querySelector("[data-next]");
    title.textContent = recipe;
    progress.max = steps.length;
    let stepIndex = 0;
    let timedStep = null;
    let remaining = 0;
    let deadline = 0;
    let interval = null;

    function renderTimer() {
      const index = timedStep ?? stepIndex;
      const step = steps[index];
      timer.hidden = !step.seconds;
      if (timer.hidden) return;
      const seconds = timedStep === null ? step.seconds : Math.ceil(remaining / 1000);
      clock.textContent = `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
      timerLabel.textContent = index === stepIndex && step.timerLabel ? step.timerLabel : `Таймер · шаг ${index + 1}`;
      timerToggle.textContent = deadline ? "Пауза" : timedStep !== null && remaining ? "Продолжить" : "Запустить";
      timerReset.disabled = timedStep === null;
    }

    function stopClock() {
      clearInterval(interval);
      interval = null;
      deadline = 0;
    }

    function tick() {
      remaining = Math.max(0, deadline - Date.now());
      if (!remaining) {
        stopClock();
        status.textContent = `Время на шаге ${timedStep + 1} вышло.`;
      }
      renderTimer();
    }

    function renderStep() {
      stepNumber.textContent = `Шаг ${stepIndex + 1} из ${steps.length}`;
      progress.value = stepIndex + 1;
      instruction.textContent = steps[stepIndex].text;
      back.disabled = stepIndex === 0;
      next.textContent = stepIndex === steps.length - 1 ? "Готово" : "Далее";
      if (timedStep !== null && !remaining && !deadline && timedStep !== stepIndex) {
        timedStep = null;
        status.textContent = "";
      }
      renderTimer();
    }

    timerToggle.addEventListener("click", () => {
      if (deadline) {
        tick();
        stopClock();
      } else {
        if (timedStep === null) timedStep = stepIndex;
        if (!remaining) remaining = steps[timedStep].seconds * 1000;
        status.textContent = "";
        deadline = Date.now() + remaining;
        interval = setInterval(tick, 250);
      }
      renderTimer();
    });
    timerReset.addEventListener("click", () => {
      stopClock();
      remaining = 0;
      timedStep = null;
      status.textContent = "";
      renderTimer();
      (timer.hidden ? instruction : timerToggle).focus();
    });
    back.addEventListener("click", () => {
      stepIndex -= 1;
      renderStep();
      instruction.focus();
    });
    next.addEventListener("click", () => {
      if (stepIndex === steps.length - 1) dialog.close();
      else {
        stepIndex += 1;
        renderStep();
        instruction.focus();
      }
    });
    dialog.querySelector("[data-close]").addEventListener("click", () => dialog.close());
    dialog.addEventListener("close", () => {
      stopClock();
      dialog.remove();
      trigger.focus();
    });
    renderStep();
    document.body.append(dialog);
    dialog.showModal();
  }

  if (typeof HTMLDialogElement !== "undefined" && "showModal" in HTMLDialogElement.prototype) {
    document.querySelectorAll("ol.steps").forEach(list => {
      const recipe = list.closest(".recipe-block")?.querySelector("h3") || document.querySelector("main h1");
      const steps = [...list.children].map(item => ({
        text: item.textContent.trim(),
        seconds: Number(item.dataset.timerSeconds),
        timerLabel: item.dataset.timerLabel
      }));
      if (!recipe || !steps.length) return;
      const trigger = makeButton("Режим готовки", "interaction-button surprise-button cooking-trigger");
      trigger.setAttribute("aria-haspopup", "dialog");
      trigger.addEventListener("click", () => openCookingMode(recipe.textContent.trim(), steps, trigger));
      list.before(trigger);
    });
  }

  if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const reveal = new IntersectionObserver(entries => {
      entries.forEach(({ target, isIntersecting }) => {
        if (!isIntersecting) return;
        target.classList.add("motion-enter");
        reveal.unobserve(target);
      });
    }, { threshold: 0.14 });
    document.querySelectorAll("#hubGrid > .recipe-card, .hero-copy, .hero-visual, .section-heading, .daily-recipe:not([hidden])")
      .forEach(element => reveal.observe(element));
  }
})();
