// Вкусно Просто: минимальный скрипт. Контент страниц отдаётся готовым HTML, JS нужен только для интерфейса.
(function () {
  var goal = function (name) {
    var counter = document.documentElement.dataset.metrikaId;
    if (counter && typeof window.ym === "function") window.ym(Number(counter), "reachGoal", name);
  };
  document.querySelectorAll('a[href^="mailto:"]').forEach(function (link) {
    link.addEventListener("click", function () { goal("contact_click"); });
  });
  var toggle = document.getElementById("menuToggle"), nav = document.getElementById("mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
      toggle.textContent = open ? "×" : "☰";
    });
  }
  function readList(key) {
    try {
      const values = JSON.parse(localStorage.getItem(key));
      return new Set(Array.isArray(values) ? values : []);
    } catch {
      return new Set();
    }
  }

  function writeList(key, values) {
    try { localStorage.setItem(key, JSON.stringify([...values])); } catch { /* Работа в текущей вкладке сохраняется. */ }
  }

  function makeButton(label, cssClass) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = cssClass;
    button.textContent = label;
    return button;
  }

  const favoritesKey = "vkusno-prosto:favorites";
  const favorites = readList(favoritesKey);
  const favoriteButtons = [];
  let refreshCatalog = function () {};

  function addFavoriteButton(container, address, title) {
    const url = new URL(address, location.href);
    const key = url.pathname + url.hash;
    const button = makeButton("", "interaction-button favorite-button");
    button.setAttribute("aria-label", "Избранное: " + title);
    function update() {
      const saved = favorites.has(key);
      button.setAttribute("aria-pressed", String(saved));
      button.textContent = saved ? "♥ В избранном" : "♡ Сохранить";
    }
    favoriteButtons.push(update);
    button.addEventListener("click", function () {
      if (favorites.has(key)) favorites.delete(key);
      else favorites.add(key);
      writeList(favoritesKey, favorites);
      favoriteButtons.forEach(updateButton => updateButton());
      refreshCatalog();
    });
    update();
    container.append(button);
    return key;
  }

  const search = document.getElementById("hubSearch");
  const grid = document.getElementById("hubGrid");
  const count = document.getElementById("hubCount");
  if (search && grid && count) {
    const cards = [...grid.children].map(card => {
      const link = card.querySelector(".card-title a");
      const searchText = card.textContent.toLowerCase();
      const key = addFavoriteButton(card, link.href, link.textContent.trim());
      return { card, link, searchText, key };
    });
    const plural = new Intl.PluralRules("ru");
    const toolbar = document.createElement("div");
    toolbar.className = "catalog-tools";
    const savedFilter = makeButton("Избранное", "interaction-button");
    savedFilter.setAttribute("aria-pressed", "false");
    const random = makeButton("Случайный рецепт", "interaction-button surprise-button");
    toolbar.append(savedFilter, random);
    count.before(toolbar);
    let onlySaved = false;
    let visibleCards = cards;
    refreshCatalog = function () {
      const query = search.value.trim().toLowerCase();
      visibleCards = cards.filter(({ card, key, searchText }) => {
        const show = searchText.includes(query) && (!onlySaved || favorites.has(key));
        card.hidden = !show;
        return show;
      });
      const shown = visibleCards.length;
      const label = { one: "рецепт", few: "рецепта", many: "рецептов" }[plural.select(shown)];
      count.textContent = shown ? `${shown} ${label}` :
        (onlySaved && !query ? "Здесь появятся сохранённые рецепты." : "Ничего не найдено. Измените запрос.");
      savedFilter.textContent = `Избранное (${cards.filter(({ key }) => favorites.has(key)).length})`;
      random.disabled = shown === 0;
    };
    savedFilter.addEventListener("click", function () {
      onlySaved = !onlySaved;
      savedFilter.setAttribute("aria-pressed", String(onlySaved));
      refreshCatalog();
    });
    random.addEventListener("click", function () {
      const choice = visibleCards[Math.floor(Math.random() * visibleCards.length)];
      if (choice) location.assign(choice.link.href);
    });
    let searchTimer;
    search.addEventListener("input", function () {
      clearTimeout(searchTimer);
      if (search.value.trim()) searchTimer = setTimeout(() => goal("recipe_search"), 700);
      refreshCatalog();
    });
    refreshCatalog();
  }

  const ingredients = document.querySelector(".ingredients");
  if (ingredients) {
    const title = document.querySelector("main h1");
    if (title) addFavoriteButton(title.parentElement, location.pathname, title.textContent.trim());
    const key = "vkusno-prosto:ingredients:" + location.pathname;
    const checked = readList(key);
    const controls = document.createElement("div");
    controls.className = "catalog-tools ingredient-tools";
    const progress = document.createElement("span");
    progress.setAttribute("aria-live", "polite");
    const reset = makeButton("Сбросить отметки", "interaction-button");
    controls.append(progress, reset);
    ingredients.before(controls);
    ingredients.classList.add("interactive-ingredients");
    const boxes = [...ingredients.children].map(item => {
      const label = document.createElement("label");
      const box = document.createElement("input");
      const name = item.textContent.trim();
      box.type = "checkbox";
      box.checked = checked.has(name);
      label.append(box, ...item.childNodes);
      item.append(label);
      box.addEventListener("change", function () {
        if (box.checked) checked.add(name);
        else checked.delete(name);
        updateProgress();
      });
      return box;
    });
    function updateProgress() {
      const done = boxes.filter(box => box.checked).length;
      progress.textContent = `Подготовлено ${done} из ${boxes.length}`;
      reset.hidden = done === 0;
      writeList(key, checked);
    }
    reset.addEventListener("click", function () {
      boxes.forEach(box => { box.checked = false; });
      checked.clear();
      updateProgress();
      boxes[0].focus();
    });
    updateProgress();
  }
})();
