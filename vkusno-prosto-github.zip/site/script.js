// Вкусно Просто: минимальный скрипт. Контент страниц отдаётся готовым HTML, JS нужен только для интерфейса.
(function () {
  var goal = function (name) {
    var counter = document.documentElement.dataset.metrikaId;
    if (counter && typeof window.ym === "function") window.ym(Number(counter), "reachGoal", name);
  };
  document.querySelectorAll('a[href^="mailto:"]').forEach(function (link) {
    link.addEventListener("click", function () { goal("contact_click"); });
  });
  var toggle = document.getElementById("menuToggle"), nav = document.getElementById("mainNav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
      toggle.textContent = open ? "×" : "☰";
    });
  }
  // Поиск по каталогу: фильтрует уже готовые карточки, без поиска страница остаётся полной.
  var search = document.getElementById("hubSearch"), grid = document.getElementById("hubGrid"), count = document.getElementById("hubCount");
  if (search && grid) {
    var cards = Array.prototype.slice.call(grid.children);
    var plural = function (n) { var a = n % 10, b = n % 100; return a === 1 && b !== 11 ? "рецепт" : (a >= 2 && a <= 4 && (b < 12 || b > 14)) ? "рецепта" : "рецептов"; };
    var searchTimer;
    search.addEventListener("input", function () {
      clearTimeout(searchTimer);
      if (search.value.trim()) searchTimer = setTimeout(function () { goal("recipe_search"); }, 700);
      var q = search.value.trim().toLowerCase(), shown = 0;
      cards.forEach(function (c) { var ok = !q || c.textContent.toLowerCase().indexOf(q) !== -1; c.hidden = !ok; if (ok) shown++; });
      count.textContent = shown ? shown + " " + plural(shown) : "Ничего не найдено. Измените запрос.";
    });
  }
})();
