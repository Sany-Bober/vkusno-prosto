(function () {
  const id = Number(document.documentElement.dataset.metrikaId);
  if (!id) return;

  const key = "vkusno-prosto-analytics";
  const read = () => { try { return localStorage.getItem(key); } catch { return null; } };
  const save = (value) => { try { localStorage.setItem(key, value); } catch { /* Storage may be disabled. */ } };

  function enable() {
    window.ym = window.ym || function () { (window.ym.a = window.ym.a || []).push(arguments); };
    window.ym.l = Date.now();
    const tag = document.createElement("script");
    tag.async = true;
    tag.src = "https://mc.yandex.ru/metrika/tag.js";
    document.head.append(tag);
    window.ym(id, "init", { clickmap: true, trackLinks: true, accurateTrackBounce: true });
    const structuredData = document.querySelector('script[type="application/ld+json"]');
    if (structuredData?.textContent.includes('"@type":"Recipe"')) window.ym(id, "reachGoal", "recipe_view");
  }

  document.getElementById("disableAnalytics")?.addEventListener("click", () => {
    save("no");
    location.reload();
  });
  if (read() === "yes") { enable(); return; }
  if (read() === "no") return;

  const bar = document.createElement("aside");
  bar.className = "analytics-choice";
  bar.setAttribute("aria-label", "Настройки аналитики");
  const label = document.createElement("p");
  label.textContent = "Разрешить Яндекс Метрику для статистики посещений?";
  bar.append(label);
  for (const [value, title] of [["yes", "Разрешить"], ["no", "Отклонить"]]) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "button button-outline";
    button.textContent = title;
    button.addEventListener("click", () => {
      save(value);
      bar.remove();
      if (value === "yes") enable();
    });
    bar.append(button);
  }
  document.body.append(bar);
})();
