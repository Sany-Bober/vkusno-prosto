import argparse
import re
import shutil
from pathlib import Path
from urllib.parse import urlsplit


parser = argparse.ArgumentParser(description='Build the static site for GitHub Pages or a local web server.')
parser.add_argument('--base-url', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--metrika-id', default='')
options = parser.parse_args()

base_url = options.base_url.rstrip('/')
address = urlsplit(base_url)
if address.scheme not in {'http', 'https'} or not address.netloc or address.query or address.fragment:
    parser.error('Use the full site address, without a query or fragment.')
if options.metrika_id and not re.fullmatch(r'[1-9][0-9]{0,11}', options.metrika_id):
    parser.error('The Yandex Metrika counter ID must be numeric.')

root = Path(__file__).resolve().parent
site = root / 'site'
shutil.copytree(site, options.output)

analytics = notice = ''
if options.metrika_id:
    analytics = '<script src="/metrika.js" defer></script>'
    notice = ('<div class="wrap"><section class="content-block prose"><h2>Аналитика посещений</h2>'
              '<p>Сайт предлагает включить Яндекс Метрику, чтобы измерять посещаемость, просмотры рецептов '
              'и использование поиска. Счётчик загружается только после выбора «Разрешить».</p>'
              '<button class="button button-outline" type="button" id="disableAnalytics">Отключить аналитику</button>'
              '</section></div>')

root_attribute = re.compile(r'''((?:href|src|action)\s*=\s*["']?)/(?!/)''', re.IGNORECASE)
for path in options.output.rglob('*'):
    if path.suffix not in {'.html', '.txt', '.xml'}:
        continue
    contents = path.read_text(encoding='utf-8')
    contents = contents.replace('@@SITE_URL@@', base_url)
    contents = contents.replace('@@ANALYTICS_TAG@@', analytics).replace('@@ANALYTICS_NOTICE@@', notice)
    if path.suffix == '.html':
        contents = root_attribute.sub(lambda m: f'{m[1]}{address.path}/', contents)
        if options.metrika_id:
            contents = contents.replace('<html lang="ru">', f'<html lang="ru" data-metrika-id="{options.metrika_id}">', 1)
    path.write_text(contents, encoding='utf-8', newline='\n')

if not options.metrika_id:
    (options.output / 'metrika.js').unlink()
(options.output / '.nojekyll').touch()
